﻿using System;
namespace Tests
{
	public class ProjectTests
	{
		public ProjectTests()
		{
		}
	}
}

