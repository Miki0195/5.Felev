﻿using System;
namespace Tests.Controllers
{
	public class UserPreferencesControllerTest
	{
		public UserPreferencesControllerTest()
		{
		}
	}
}

