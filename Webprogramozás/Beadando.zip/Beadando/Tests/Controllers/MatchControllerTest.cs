﻿using System;
namespace Tests.Controllers
{
	public class MatchControllerTest
	{
		public MatchControllerTest()
		{
		}
	}
}

