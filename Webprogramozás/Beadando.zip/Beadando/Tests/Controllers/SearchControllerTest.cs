﻿using System;
namespace Tests.Controllers
{
	public class SearchControllerTest
	{
		public SearchControllerTest()
		{
		}
	}
}

