﻿namespace Beadando.Models
{
    public class UserPreferenceViewModel
    {
        public string TeamName { get; set; } = string.Empty; 
        public int PreferenceCount { get; set; } 
    }
}