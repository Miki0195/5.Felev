﻿using System;

namespace Beadando.Models
{
    public class LeagueSelectionViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsSelected { get; set; }
    }
}
