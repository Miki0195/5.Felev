﻿using System;
namespace Tests.Controllers
{
	public class FavoriteTeamControllerTest
	{
		public FavoriteTeamControllerTest()
		{
		}
	}
}

