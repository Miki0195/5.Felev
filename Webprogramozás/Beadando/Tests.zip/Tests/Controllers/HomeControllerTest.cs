﻿using System;
namespace Tests.Controllers
{
	public class HomeControllerTest
	{
		public HomeControllerTest()
		{
		}
	}
}

