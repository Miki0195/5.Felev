﻿using System;
namespace Tests.Controllers
{
	public class LeagueControllerTest
	{
		public LeagueControllerTest()
		{
		}
	}
}

