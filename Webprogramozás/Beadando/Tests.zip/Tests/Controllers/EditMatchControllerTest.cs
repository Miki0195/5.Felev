﻿using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Beadando.Controllers;
using Beadando.Data;
using Beadando.Models;
using System.Collections.Generic;
using System.Linq;
using DomainMatch = Beadando.Models.Match;

public class EditMatchControllerTests
{
    private SportsDbContext GetInMemoryDbContext()
    {
        var options = new DbContextOptionsBuilder<SportsDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique database name per test
            .Options;

        var context = new SportsDbContext(options);

        // Seed data for testing
        context.Teams.AddRange(
            new Team { Id = 1, Name = "TeamA" },
            new Team { Id = 2, Name = "TeamB" }
        );

        context.Leagues.AddRange(
            new League { Id = 1, Name = "League1" }
        );

        context.Matches.AddRange(
            new DomainMatch 
            {
                Id = 1,
                HomeTeamId = 1,
                AwayTeamId = 2,
                LeagueId = 1,
                StartTime = DateTime.Now,
                FinalScore = "2:1",
                HalfTimeScore = "1:0",
                Report = "Match Report"
            }
        );

        context.SaveChanges();

        return context;
    }

    [Fact]
    public void Create_Get_ReturnsViewWithTeamsAndLeagues()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.Create() as ViewResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal("~/Views/Match/Create.cshtml", result.ViewName);
        Assert.NotNull(result.ViewData["Teams"]);
        Assert.NotNull(result.ViewData["Leagues"]);
    }

    [Fact]
    public void Create_Post_ValidModel_AddsMatch()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);
        var match = new DomainMatch
        {
            HomeTeamId = 1,
            AwayTeamId = 2,
            LeagueId = 1,
            StartTime = System.DateTime.Now,
            FinalScore = "1:0",
            HalfTimeScore = "0:0",
            Report = "Test Report"
        };

        // Act
        var result = controller.Create(match) as ViewResult;

        // Assert
        Assert.NotNull(result);
        Assert.True(context.Matches.Count() > 1); // New match added
        Assert.NotNull(result.TempData["CreateSuccessMessage"]);
    }

    [Fact]
    public void SearchMatches_ValidTeamName_ReturnsMatches()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.SearchMatches("TeamA") as ViewResult;

        // Assert
        Assert.NotNull(result);
        var matches = result.Model as List<MatchViewModel>;
        Assert.Single(matches); // Match for TeamA
    }

    [Fact]
    public void DeleteMatch_ValidId_RemovesMatch()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.DeleteMatch(1) as RedirectToActionResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal("SearchMatches", result.ActionName);
        Assert.Empty(context.Matches); // Match deleted
    }

    [Fact]
    public void SearchMatchesForEdit_ValidTeamName_ReturnsMatches()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.SearchMatchesForEdit("TeamA") as ViewResult;

        // Assert
        Assert.NotNull(result);
        var matches = result.Model as List<MatchViewModel>;
        Assert.Single(matches); // Match for TeamA
    }

    [Fact]
    public void EditMatch_Get_ValidId_ReturnsPartialViewWithMatch()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.EditMatch(1) as PartialViewResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal("~/Views/Match/_EditMatchModal.cshtml", result.ViewName);
        var match = result.Model as DomainMatch;
        Assert.Equal(1, match.Id);
    }

    [Fact]
    public void EditMatch_Post_ValidModel_UpdatesMatch()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);
        var updatedMatch = new DomainMatch
        {
            Id = 1,
            HomeTeamId = 1,
            AwayTeamId = 2,
            LeagueId = 1,
            StartTime = System.DateTime.Now,
            FinalScore = "3:2",
            HalfTimeScore = "1:1",
            Report = "Updated Report"
        };

        // Act
        var result = controller.EditMatch(updatedMatch, "TeamA") as ViewResult;

        // Assert
        Assert.NotNull(result);
        Assert.Equal("3:2", context.Matches.First().FinalScore); // Match updated
        Assert.NotNull(result.TempData["EditSuccessMessage"]);
    }

    [Fact]
    public void GetTeamsByLeague_ValidLeagueId_ReturnsTeams()
    {
        // Arrange
        var context = GetInMemoryDbContext();
        var controller = new EditMatchController(context);

        // Act
        var result = controller.GetTeamsByLeague(1) as JsonResult;

        // Assert
        Assert.NotNull(result);
        var teams = result.Value as List<dynamic>;
        Assert.NotEmpty(teams);
        Assert.Equal(2, teams.Count); // Teams in League1
    }
}
