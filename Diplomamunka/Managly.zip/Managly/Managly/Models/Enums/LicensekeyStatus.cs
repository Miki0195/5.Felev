﻿using System;
namespace Managly.Models.Enums
{
	public enum LicensekeyStatus
	{
		Active,
		Expired,
		Available
	}
}

