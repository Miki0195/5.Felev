﻿namespace Managly.Models.Enums
{
    public enum CallStatus
    {
        Active,
        Ended,
        Missed,
        Pending
    }
}
