﻿using System;
namespace Managly.Models
{
    public class LeaveUpdateDTO
    {
        public DateTime LeaveDate { get; set; }
    }

}

