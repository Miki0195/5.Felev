public class GroupMessageDto
{
    public int GroupId { get; set; }
    public string Content { get; set; }
} 