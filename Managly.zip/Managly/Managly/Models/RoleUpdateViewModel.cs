﻿using System;
namespace Managly.Models
{
    public class RoleUpdateViewModel
    {
        public string Role { get; set; }
    }
}

