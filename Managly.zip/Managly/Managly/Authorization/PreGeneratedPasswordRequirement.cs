﻿using Microsoft.AspNetCore.Authorization;

public class PreGeneratedPasswordRequirement : IAuthorizationRequirement
{

}
